﻿
Partial Class stringSearch
    Inherits System.Web.UI.Page

End Class
